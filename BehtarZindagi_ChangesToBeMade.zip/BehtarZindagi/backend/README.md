# BehtarZindagi Backend v2

A scalable NestJS backend application with Express.js for the BehtarZindagi platform.

## Features

- 🚀 **NestJS Framework** - Modern, scalable Node.js framework
- 🛡️ **Express.js Platform** - Fast, unopinionated web framework
- 📦 **Modular Architecture** - Well-structured controllers, services, and modules
- 🔒 **Security** - CORS, validation, and error handling
- 📝 **Logging** - Comprehensive request/response logging
- ⚡ **TypeScript** - Full type safety and modern JavaScript features
- 🧪 **Testing Ready** - Jest configuration included

## Project Structure

```
src/
├── common/
│   ├── filters/
│   │   └── all-exceptions.filter.ts
│   └── middlewares/
│       └── logger.middleware.ts
├── health/
│   └── health.controller.ts
├── products/
│   ├── dto/
│   │   └── get-products.dto.ts
│   ├── products.controller.ts
│   ├── products.module.ts
│   └── products.service.ts
├── app.module.ts
└── main.ts
```

## Installation

1. Install dependencies:
```bash
npm install
```

2. Copy environment configuration:
```bash
cp config.env.example .env
```

3. Update `.env` file with your configuration

## Running the Application

### Development
```bash
npm run dev
```

### Production
```bash
npm run build
npm run start:prod
```

### Debug Mode
```bash
npm run start:debug
```

## API Endpoints

### Health Check
- **GET** `/api/health` - Application health status

### Products
- **GET** `/api/products` - Get all products
  - Query Parameters:
    - `pageIndex` (optional, default: 1) - Page number
    - `pageSize` (optional, default: 8, max: 100) - Items per page

## Example Usage

### Get Products
```bash
curl "http://localhost:3000/api/products?pageIndex=1&pageSize=8"
```

### Health Check
```bash
curl "http://localhost:3000/api/health"
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `NODE_ENV` | Environment mode | `development` |
| `PORT` | Server port | `3000` |
| `EXTERNAL_API_URL` | External API endpoint | `https://behtarzindagi.in/BZFarmerApp_Live/api/Home/GetAllProducts` |
| `ALLOWED_ORIGINS` | CORS allowed origins | `http://localhost:3000,http://localhost:3001` |

## Development

### Code Formatting
```bash
npm run format
```

### Linting
```bash
npm run lint
```

### Testing
```bash
# Unit tests
npm run test

# E2E tests
npm run test:e2e

# Test coverage
npm run test:cov
```

## Architecture

### Controllers
Handle HTTP requests and responses, validate input, and call services.

### Services
Contain business logic, external API calls, and data processing.

### Middleware
Process requests before they reach controllers (logging, authentication, etc.).

### Filters
Handle exceptions and errors globally.

### DTOs
Data Transfer Objects for request/response validation.

## Adding New Features

1. Create a new module: `nest generate module feature-name`
2. Create controller: `nest generate controller feature-name`
3. Create service: `nest generate service feature-name`
4. Add routes and business logic
5. Update `app.module.ts` to include the new module

## Contributing

1. Follow the existing code structure
2. Add proper error handling
3. Include logging for important operations
4. Write tests for new features
5. Update documentation

## License

ISC
#   b e h t a r z i n d a g i - b a c k e n d - v 2  
 